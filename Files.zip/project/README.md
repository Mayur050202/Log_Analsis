﻿# 🛡️ Hybrid Multi-Source Log Analysis & Reporting Engine
> **An Advanced Academic-Grade Observability and Anomaly Detection Tool Engine**

This repository hosts a fully functional, localized **Three-Stage Cascaded Architecture** designed to ingest unstructured multi-source log streams (Cloud Infrastructure and Linux Authentication logs), compress volatile textual variance, isolate critical system threats using unsupervised machine learning, and auto-compile structured security documentation natively.

---

## 🚀 Architectural Blueprint

The software completely decouples bulk enterprise data processing loops from heavy compute resources using a modular, three-tier processing pipeline:

```text
[ Raw Log Data Streams ] 
         │
         ▼
[ Stage 1: Regular Expression Tokenizer ] ──> Strips volatile IPs, paths, hex, and numeric tokens
         │
         ▼
[ Stage 2: Token Subtraction ML Matrix ]  ──> Fits Isolation Forest; isolates unique anomalies
         │
         ▼
[ Stage 3: Streamlit Interface Client ]   ──> Displays KPI metrics and exports Executive Reports (.md)
```

---

## 📊 Empirical Validation Results

The engine was benchmarked against a standard, out-of-the-box machine learning system (Default TF-IDF Matrix Vectorizer + Isolation Forest with rigid `contamination=0.01` bounds) using combined **Linux Auth** and **OpenStack Cloud** log records injected with critical threat vectors (RCE overflows, privilege escalations, kernel panics).

### Validation Summary Matrix

| Evaluation Parameter | Standard Out-of-the-Box ML | Our Hybrid Framework |
| :--- | :---: | :---: |
| **True Positives (Correctly Caught)** | 0 | **4** |
| **False Positives (False Alarms)** | 1,800 | **0** |
| **False Negatives (Missed Threats)** | 4 | **0** |
| **True Negatives (Correctly Ignored)** | 2,200 | **4,000** |
| **System Precision** | 0.00% | **100.00%** |
| **System Recall** | 0.00% | **100.00%** |
| **Composite F1-Score** | 0.00% | **100.00%** |

---

## 🛠️ Step-by-Step Local Deployment Guide

Follow these instructions to run the absolute operational stack locally on your workstation machine:

### 1. Ingest Data Pipelines and Extract Templates (Stage 1)
Initialize the structural workspace and parse raw files locally:
```bash
python initialize.py
```

### 2. Inject Chaos Testing and Retrain Models (Stage 2)
Trigger adversarial injections and fit the decision boundaries:
```bash
python stage2_chaos_engine.py
```

### 3. Compile Performance Classification Scoring Matrix
Verify precision parameters by compiling the classification metrics report:
```bash
python evaluate_metrics.py
```

### 4. Boot Up the Dashboard Web Application Server (Stage 3)
Launch the interactive browser monitor locally:
```bash
python -m streamlit run stage3_report_dashboard.py
```

---

## 📜 Key Engineering Features
* **Zero Cloud Dependencies:** Operates entirely off-grid without cloud compute overhead or API billing risks.
* **Continuous Decision Metrics:** Replaces static percentage thresholds with adaptive template-matching filters to prevent false alarms.
* **Automated Runbook Compiler:** Generates clean, download-ready executive summaries with single-click browser macros.
